/* blender.h    dec 93 */


#include <sys/types.h>
#include <string.h>
#include <local/util.h>
#include <local/iff.h>
