
/* GENERATED FILE -- DO NOT MODIFY */

#include "glutbitmap.h"

/* char: 0xff */

static GLubyte ch255data[] = {
0x80,0x40,0x60,0x90,0x90,0x90,0x0,0x50,
};

static BitmapCharRec ch255 = {4,8,-1,1,4,ch255data};

/* char: 0xfe */

static GLubyte ch254data[] = {
0x80,0xe0,0x90,0x90,0x90,0xe0,0x80,
};

static BitmapCharRec ch254 = {4,7,-1,1,5,ch254data};

/* char: 0xfd */

static GLubyte ch253data[] = {
0x80,0x40,0x60,0x90,0x90,0x90,0x0,0x20,0x10,
};

static BitmapCharRec ch253 = {4,9,-1,1,4,ch253data};

/* char: 0xfc */

static GLubyte ch252data[] = {
0x60,0xa0,0xa0,0xa0,0xa0,0x0,0xa0,
};

static BitmapCharRec ch252 = {3,7,-1,0,4,ch252data};

/* char: 0xfb */

static GLubyte ch251data[] = {
0x60,0xa0,0xa0,0xa0,0xa0,0x0,0xa0,0x40,
};

static BitmapCharRec ch251 = {3,8,-1,0,4,ch251data};

/* char: 0xfa */

static GLubyte ch250data[] = {
0x60,0xa0,0xa0,0xa0,0xa0,0x0,0x40,0x20,
};

static BitmapCharRec ch250 = {3,8,-1,0,4,ch250data};

/* char: 0xf9 */

static GLubyte ch249data[] = {
0x60,0xa0,0xa0,0xa0,0xa0,0x0,0x40,0x80,
};

static BitmapCharRec ch249 = {3,8,-1,0,4,ch249data};

/* char: 0xf8 */

static GLubyte ch248data[] = {
0x80,0x70,0x68,0x58,0x48,0x3c,0x2,
};

static BitmapCharRec ch248 = {7,7,0,1,5,ch248data};

/* char: 0xf7 */

static GLubyte ch247data[] = {
0x20,0x0,0xf0,0x0,0x20,
};

static BitmapCharRec ch247 = {4,5,-1,0,5,ch247data};

/* char: 0xf6 */

static GLubyte ch246data[] = {
0x60,0x90,0x90,0x90,0x60,0x0,0x90,
};

static BitmapCharRec ch246 = {4,7,-1,0,5,ch246data};

/* char: 0xf5 */

static GLubyte ch245data[] = {
0x60,0x90,0x90,0x90,0x60,0x0,0xa0,0x50,
};

static BitmapCharRec ch245 = {4,8,-1,0,5,ch245data};

/* char: 0xf4 */

static GLubyte ch244data[] = {
0x60,0x90,0x90,0x90,0x60,0x0,0xa0,0x40,
};

static BitmapCharRec ch244 = {4,8,-1,0,5,ch244data};

/* char: 0xf3 */

static GLubyte ch243data[] = {
0x60,0x90,0x90,0x90,0x60,0x0,0x20,0x10,
};

static BitmapCharRec ch243 = {4,8,-1,0,5,ch243data};

/* char: 0xf2 */

static GLubyte ch242data[] = {
0x60,0x90,0x90,0x90,0x60,0x0,0x20,0x40,
};

static BitmapCharRec ch242 = {4,8,-1,0,5,ch242data};

/* char: 0xf1 */

static GLubyte ch241data[] = {
0x90,0x90,0x90,0x90,0xe0,0x0,0xa0,0x50,
};

static BitmapCharRec ch241 = {4,8,-1,0,5,ch241data};

/* char: 0xf0 */

static GLubyte ch240data[] = {
0x60,0x90,0x90,0x90,0x70,0xa0,0x60,0x90,
};

static BitmapCharRec ch240 = {4,8,-1,0,5,ch240data};

/* char: 0xef */

static GLubyte ch239data[] = {
0x40,0x40,0x40,0x40,0x40,0x0,0xa0,
};

static BitmapCharRec ch239 = {3,7,0,0,2,ch239data};

/* char: 0xee */

static GLubyte ch238data[] = {
0x40,0x40,0x40,0x40,0x40,0x0,0xa0,0x40,
};

static BitmapCharRec ch238 = {3,8,0,0,2,ch238data};

/* char: 0xed */

static GLubyte ch237data[] = {
0x80,0x80,0x80,0x80,0x80,0x0,0x80,0x40,
};

static BitmapCharRec ch237 = {2,8,-1,0,2,ch237data};

/* char: 0xec */

static GLubyte ch236data[] = {
0x40,0x40,0x40,0x40,0x40,0x0,0x40,0x80,
};

static BitmapCharRec ch236 = {2,8,0,0,2,ch236data};

/* char: 0xeb */

static GLubyte ch235data[] = {
0x60,0x80,0xe0,0xa0,0x40,0x0,0xa0,
};

static BitmapCharRec ch235 = {3,7,-1,0,4,ch235data};

/* char: 0xea */

static GLubyte ch234data[] = {
0x60,0x80,0xe0,0xa0,0x40,0x0,0xa0,0x40,
};

static BitmapCharRec ch234 = {3,8,-1,0,4,ch234data};

/* char: 0xe9 */

static GLubyte ch233data[] = {
0x60,0x80,0xe0,0xa0,0x40,0x0,0x40,0x20,
};

static BitmapCharRec ch233 = {3,8,-1,0,4,ch233data};

/* char: 0xe8 */

static GLubyte ch232data[] = {
0x60,0x80,0xe0,0xa0,0x40,0x0,0x20,0x40,
};

static BitmapCharRec ch232 = {3,8,-1,0,4,ch232data};

/* char: 0xe7 */

static GLubyte ch231data[] = {
0x80,0x40,0x60,0x80,0x80,0x80,0x60,
};

static BitmapCharRec ch231 = {3,7,-1,2,4,ch231data};

/* char: 0xe6 */

static GLubyte ch230data[] = {
0xd8,0xa0,0xf8,0x28,0xd0,
};

static BitmapCharRec ch230 = {5,5,-1,0,6,ch230data};

/* char: 0xe5 */

static GLubyte ch229data[] = {
0xd0,0xa0,0xe0,0x20,0xc0,0x40,0xa0,0x40,
};

static BitmapCharRec ch229 = {4,8,-1,0,4,ch229data};

/* char: 0xe4 */

static GLubyte ch228data[] = {
0xd0,0xa0,0xe0,0x20,0xc0,0x0,0xa0,
};

static BitmapCharRec ch228 = {4,7,-1,0,4,ch228data};

/* char: 0xe3 */

static GLubyte ch227data[] = {
0x68,0x50,0x70,0x10,0x60,0x0,0xb0,0x68,
};

static BitmapCharRec ch227 = {5,8,0,0,4,ch227data};

/* char: 0xe2 */

static GLubyte ch226data[] = {
0xd0,0xa0,0xe0,0x20,0xc0,0x0,0xa0,0x40,
};

static BitmapCharRec ch226 = {4,8,-1,0,4,ch226data};

/* char: 0xe1 */

static GLubyte ch225data[] = {
0xd0,0xa0,0xe0,0x20,0xc0,0x0,0x40,0x20,
};

static BitmapCharRec ch225 = {4,8,-1,0,4,ch225data};

/* char: 0xe0 */

static GLubyte ch224data[] = {
0xd0,0xa0,0xe0,0x20,0xc0,0x0,0x40,0x80,
};

static BitmapCharRec ch224 = {4,8,-1,0,4,ch224data};

/* char: 0xdf */

static GLubyte ch223data[] = {
0x80,0xa0,0x90,0x90,0xa0,0x90,0x60,
};

static BitmapCharRec ch223 = {4,7,-2,1,6,ch223data};

/* char: 0xde */

static GLubyte ch222data[] = {
0x80,0xf0,0x88,0x88,0xf0,0x80,
};

static BitmapCharRec ch222 = {5,6,-1,0,6,ch222data};

/* char: 0xdd */

static GLubyte ch221data[] = {
0x20,0x20,0x30,0x48,0x48,0xc8,0x0,0x10,0x8,
};

static BitmapCharRec ch221 = {5,9,-1,0,6,ch221data};

/* char: 0xdc */

static GLubyte ch220data[] = {
0x70,0x88,0x88,0x88,0x88,0x88,0x0,0x50,
};

static BitmapCharRec ch220 = {5,8,-1,0,6,ch220data};

/* char: 0xdb */

static GLubyte ch219data[] = {
0x70,0x88,0x88,0x88,0x88,0x88,0x0,0x50,0x20,
};

static BitmapCharRec ch219 = {5,9,-1,0,6,ch219data};

/* char: 0xda */

static GLubyte ch218data[] = {
0x70,0x88,0x88,0x88,0x88,0x88,0x0,0x20,0x10,
};

static BitmapCharRec ch218 = {5,9,-1,0,6,ch218data};

/* char: 0xd9 */

static GLubyte ch217data[] = {
0x70,0x88,0x88,0x88,0x88,0x88,0x0,0x20,0x40,
};

static BitmapCharRec ch217 = {5,9,-1,0,6,ch217data};

/* char: 0xd8 */

static GLubyte ch216data[] = {
0x80,0xf0,0xc8,0xa8,0x98,0x88,0x78,0x8,
};

static BitmapCharRec ch216 = {5,8,-1,1,6,ch216data};

/* char: 0xd7 */

static GLubyte ch215data[] = {
0x90,0x60,0x60,0x90,
};

static BitmapCharRec ch215 = {4,4,-1,0,5,ch215data};

/* char: 0xd6 */

static GLubyte ch214data[] = {
0x70,0x88,0x88,0x88,0x88,0x70,0x0,0x50,
};

static BitmapCharRec ch214 = {5,8,-1,0,6,ch214data};

/* char: 0xd5 */

static GLubyte ch213data[] = {
0x70,0x88,0x88,0x88,0x88,0x70,0x0,0x50,0x28,
};

static BitmapCharRec ch213 = {5,9,-1,0,6,ch213data};

/* char: 0xd4 */

static GLubyte ch212data[] = {
0x70,0x88,0x88,0x88,0x88,0x70,0x0,0x50,0x20,
};

static BitmapCharRec ch212 = {5,9,-1,0,6,ch212data};

/* char: 0xd3 */

static GLubyte ch211data[] = {
0x70,0x88,0x88,0x88,0x88,0x70,0x0,0x20,0x10,
};

static BitmapCharRec ch211 = {5,9,-1,0,6,ch211data};

/* char: 0xd2 */

static GLubyte ch210data[] = {
0x70,0x88,0x88,0x88,0x88,0x70,0x0,0x20,0x40,
};

static BitmapCharRec ch210 = {5,9,-1,0,6,ch210data};

/* char: 0xd1 */

static GLubyte ch209data[] = {
0x88,0x98,0xa8,0xa8,0xc8,0x88,0x0,0x50,0x28,
};

static BitmapCharRec ch209 = {5,9,-1,0,6,ch209data};

/* char: 0xd0 */

static GLubyte ch208data[] = {
0x70,0x48,0x48,0xe8,0x48,0x70,
};

static BitmapCharRec ch208 = {5,6,-1,0,6,ch208data};

/* char: 0xcf */

static GLubyte ch207data[] = {
0x40,0x40,0x40,0x40,0x40,0x40,0x0,0xa0,
};

static BitmapCharRec ch207 = {3,8,0,0,2,ch207data};

/* char: 0xce */

static GLubyte ch206data[] = {
0x40,0x40,0x40,0x40,0x40,0x40,0x0,0xa0,0x40,
};

static BitmapCharRec ch206 = {3,9,0,0,2,ch206data};

/* char: 0xcd */

static GLubyte ch205data[] = {
0x80,0x80,0x80,0x80,0x80,0x80,0x0,0x80,0x40,
};

static BitmapCharRec ch205 = {2,9,-1,0,2,ch205data};

/* char: 0xcc */

static GLubyte ch204data[] = {
0x40,0x40,0x40,0x40,0x40,0x40,0x0,0x40,0x80,
};

static BitmapCharRec ch204 = {2,9,0,0,2,ch204data};

/* char: 0xcb */

static GLubyte ch203data[] = {
0xf0,0x80,0x80,0xe0,0x80,0xf0,0x0,0xa0,
};

static BitmapCharRec ch203 = {4,8,-2,0,6,ch203data};

/* char: 0xca */

static GLubyte ch202data[] = {
0xf0,0x80,0x80,0xe0,0x80,0xf0,0x0,0xa0,0x40,
};

static BitmapCharRec ch202 = {4,9,-2,0,6,ch202data};

/* char: 0xc9 */

static GLubyte ch201data[] = {
0xf0,0x80,0x80,0xe0,0x80,0xf0,0x0,0x40,0x20,
};

static BitmapCharRec ch201 = {4,9,-2,0,6,ch201data};

/* char: 0xc8 */

static GLubyte ch200data[] = {
0xf0,0x80,0x80,0xe0,0x80,0xf0,0x0,0x20,0x40,
};

static BitmapCharRec ch200 = {4,9,-2,0,6,ch200data};

/* char: 0xc7 */

static GLubyte ch199data[] = {
0x80,0x40,0x70,0x88,0x80,0x88,0x88,0x70,
};

static BitmapCharRec ch199 = {5,8,-1,2,6,ch199data};

/* char: 0xc6 */

static GLubyte ch198data[] = {
0x9e,0x90,0x7c,0x50,0x30,0x3e,
};

static BitmapCharRec ch198 = {7,6,-1,0,8,ch198data};

/* char: 0xc5 */

static GLubyte ch197data[] = {
0x88,0x88,0x70,0x50,0x20,0x20,0x20,0x50,0x20,
};

static BitmapCharRec ch197 = {5,9,-1,0,6,ch197data};

/* char: 0xc4 */

static GLubyte ch196data[] = {
0x88,0x88,0x70,0x50,0x20,0x20,0x0,0x50,
};

static BitmapCharRec ch196 = {5,8,-1,0,6,ch196data};

/* char: 0xc3 */

static GLubyte ch195data[] = {
0x88,0x88,0x70,0x50,0x20,0x20,0x0,0x50,0x28,
};

static BitmapCharRec ch195 = {5,9,-1,0,6,ch195data};

/* char: 0xc2 */

static GLubyte ch194data[] = {
0x88,0x88,0x70,0x50,0x20,0x20,0x0,0x50,0x20,
};

static BitmapCharRec ch194 = {5,9,-1,0,6,ch194data};

/* char: 0xc1 */

static GLubyte ch193data[] = {
0x88,0x88,0x70,0x50,0x20,0x20,0x0,0x20,0x10,
};

static BitmapCharRec ch193 = {5,9,-1,0,6,ch193data};

/* char: 0xc0 */

static GLubyte ch192data[] = {
0x88,0x88,0x70,0x50,0x20,0x20,0x0,0x20,0x40,
};

static BitmapCharRec ch192 = {5,9,-1,0,6,ch192data};

/* char: 0xbf */

static GLubyte ch191data[] = {
0x60,0x90,0x40,0x20,0x0,0x20,
};

static BitmapCharRec ch191 = {4,6,-1,1,5,ch191data};

/* char: 0xbe */

static GLubyte ch190data[] = {
0x4,0x5e,0x2c,0xd4,0x28,0x64,0xe0,
};

static BitmapCharRec ch190 = {7,7,0,1,7,ch190data};

/* char: 0xbd */

static GLubyte ch189data[] = {
0xe,0x44,0x22,0x5c,0x48,0xc4,0x40,
};

static BitmapCharRec ch189 = {7,7,0,1,7,ch189data};

/* char: 0xbc */

static GLubyte ch188data[] = {
0x4,0x5e,0x2c,0x54,0x48,0xc4,0x40,
};

static BitmapCharRec ch188 = {7,7,0,1,7,ch188data};

/* char: 0xbb */

static GLubyte ch187data[] = {
0xa0,0x50,0xa0,
};

static BitmapCharRec ch187 = {4,3,-1,-1,5,ch187data};

/* char: 0xba */

static GLubyte ch186data[] = {
0xe0,0x0,0xe0,0xa0,0xe0,
};

static BitmapCharRec ch186 = {3,5,0,-1,3,ch186data};

/* char: 0xb9 */

static GLubyte ch185data[] = {
0x40,0x40,0xc0,0x40,
};

static BitmapCharRec ch185 = {2,4,0,-2,2,ch185data};

/* char: 0xb8 */

static GLubyte ch184data[] = {
0x80,0x40,
};

static BitmapCharRec ch184 = {2,2,0,2,2,ch184data};

/* char: 0xb7 */

static GLubyte ch183data[] = {
0x80,0x80,
};

static BitmapCharRec ch183 = {1,2,-1,-1,2,ch183data};

/* char: 0xb6 */

static GLubyte ch182data[] = {
0x50,0x50,0x50,0x50,0xd0,0xd0,0xd0,0x78,
};

static BitmapCharRec ch182 = {5,8,0,2,5,ch182data};

/* char: 0xb5 */

static GLubyte ch181data[] = {
0x80,0x80,0xe0,0xa0,0xa0,0xa0,
};

static BitmapCharRec ch181 = {3,6,-1,2,4,ch181data};

/* char: 0xb4 */

static GLubyte ch180data[] = {
0x80,0x40,
};

static BitmapCharRec ch180 = {2,2,0,-4,2,ch180data};

/* char: 0xb3 */

static GLubyte ch179data[] = {
0xc0,0x20,0x60,0xe0,
};

static BitmapCharRec ch179 = {3,4,0,-2,2,ch179data};

/* char: 0xb2 */

static GLubyte ch178data[] = {
0xc0,0x80,0x40,0x80,
};

static BitmapCharRec ch178 = {2,4,-1,-2,2,ch178data};

/* char: 0xb1 */

static GLubyte ch177data[] = {
0xf0,0x0,0x20,0xf0,0x20,
};

static BitmapCharRec ch177 = {4,5,-1,0,5,ch177data};

/* char: 0xb0 */

static GLubyte ch176data[] = {
0x40,0xa0,0x40,
};

static BitmapCharRec ch176 = {3,3,-1,-3,3,ch176data};

/* char: 0xaf */

static GLubyte ch175data[] = {
0xe0,
};

static BitmapCharRec ch175 = {3,1,0,-5,2,ch175data};

/* char: 0xae */

static GLubyte ch174data[] = {
0x78,0x84,0xac,0xb4,0xb4,0x84,0x78,
};

static BitmapCharRec ch174 = {6,7,-1,1,7,ch174data};

/* char: 0xad */

static GLubyte ch173data[] = {
0xc0,
};

static BitmapCharRec ch173 = {2,1,0,-2,3,ch173data};

/* char: 0xac */

static GLubyte ch172data[] = {
0x10,0x10,0xf0,
};

static BitmapCharRec ch172 = {4,3,-1,-1,6,ch172data};

/* char: 0xab */

static GLubyte ch171data[] = {
0x50,0xa0,0x50,
};

static BitmapCharRec ch171 = {4,3,-1,-1,5,ch171data};

/* char: 0xaa */

static GLubyte ch170data[] = {
0xe0,0x0,0xe0,0x20,0xc0,
};

static BitmapCharRec ch170 = {3,5,0,-1,3,ch170data};

/* char: 0xa9 */

static GLubyte ch169data[] = {
0x78,0x84,0xb4,0xa4,0xb4,0x84,0x78,
};

static BitmapCharRec ch169 = {6,7,-1,1,7,ch169data};

/* char: 0xa8 */

static GLubyte ch168data[] = {
0x90,
};

static BitmapCharRec ch168 = {4,1,0,-5,2,ch168data};

/* char: 0xa7 */

static GLubyte ch167data[] = {
0xe0,0x10,0x30,0x60,0x90,0x60,0x80,0x70,
};

static BitmapCharRec ch167 = {4,8,-1,2,5,ch167data};

/* char: 0xa6 */

static GLubyte ch166data[] = {
0x80,0x80,0x80,0x0,0x80,0x80,0x80,
};

static BitmapCharRec ch166 = {1,7,-1,1,2,ch166data};

/* char: 0xa5 */

static GLubyte ch165data[] = {
0x20,0x20,0xf8,0x50,0x88,
};

static BitmapCharRec ch165 = {5,5,-1,0,6,ch165data};

/* char: 0xa4 */

static GLubyte ch164data[] = {
0x88,0x70,0x50,0x70,0x88,
};

static BitmapCharRec ch164 = {5,5,0,0,4,ch164data};

/* char: 0xa3 */

static GLubyte ch163data[] = {
0xf0,0x40,0x40,0xe0,0x40,0x30,
};

static BitmapCharRec ch163 = {4,6,-1,0,5,ch163data};

/* char: 0xa2 */

static GLubyte ch162data[] = {
0x40,0x40,0xa0,0x80,0xa0,0x40,0x40,
};

static BitmapCharRec ch162 = {3,7,-1,1,5,ch162data};

/* char: 0xa1 */

static GLubyte ch161data[] = {
0x80,0x80,0x80,0x80,0x80,0x0,0x80,
};

static BitmapCharRec ch161 = {1,7,-1,2,2,ch161data};

/* char: 0xa0 */

static GLubyte ch160data[] = {
0x0,
};

static BitmapCharRec ch160 = {1,1,0,0,2,ch160data};

/* char: 0x7e '~' */

static GLubyte ch126data[] = {
0xb0,0x48,
};

static BitmapCharRec ch126 = {5,2,-1,-2,6,ch126data};

/* char: 0x7d '}' */

static GLubyte ch125data[] = {
0x80,0x40,0x40,0x60,0x40,0x40,0x80,
};

static BitmapCharRec ch125 = {3,7,0,1,2,ch125data};

/* char: 0x7c '|' */

static GLubyte ch124data[] = {
0x80,0x80,0x80,0x80,0x80,0x80,0x80,
};

static BitmapCharRec ch124 = {1,7,-1,1,2,ch124data};

/* char: 0x7b '{' */

static GLubyte ch123data[] = {
0x20,0x40,0x40,0xc0,0x40,0x40,0x20,
};

static BitmapCharRec ch123 = {3,7,0,1,2,ch123data};

/* char: 0x7a 'z' */

static GLubyte ch122data[] = {
0xe0,0x80,0x40,0x20,0xe0,
};

static BitmapCharRec ch122 = {3,5,-1,0,4,ch122data};

/* char: 0x79 'y' */

static GLubyte ch121data[] = {
0x80,0x40,0x60,0x90,0x90,0x90,
};

static BitmapCharRec ch121 = {4,6,-1,1,4,ch121data};

/* char: 0x78 'x' */

static GLubyte ch120data[] = {
0x90,0x90,0x60,0x90,0x90,
};

static BitmapCharRec ch120 = {4,5,-1,0,5,ch120data};

/* char: 0x77 'w' */

static GLubyte ch119data[] = {
0x50,0x50,0xa8,0xa8,0xa8,
};

static BitmapCharRec ch119 = {5,5,-1,0,6,ch119data};

/* char: 0x76 'v' */

static GLubyte ch118data[] = {
0x40,0xa0,0x90,0x90,0x90,
};

static BitmapCharRec ch118 = {4,5,-1,0,5,ch118data};

/* char: 0x75 'u' */

static GLubyte ch117data[] = {
0x60,0xa0,0xa0,0xa0,0xa0,
};

static BitmapCharRec ch117 = {3,5,-1,0,4,ch117data};

/* char: 0x74 't' */

static GLubyte ch116data[] = {
0x40,0x40,0x40,0x40,0xe0,0x40,0x40,
};

static BitmapCharRec ch116 = {3,7,-1,0,3,ch116data};

/* char: 0x73 's' */

static GLubyte ch115data[] = {
0xc0,0x20,0x60,0x80,0x60,
};

static BitmapCharRec ch115 = {3,5,-1,0,4,ch115data};

/* char: 0x72 'r' */

static GLubyte ch114data[] = {
0x80,0x80,0x80,0xc0,0xa0,
};

static BitmapCharRec ch114 = {3,5,-1,0,3,ch114data};

/* char: 0x71 'q' */

static GLubyte ch113data[] = {
0x10,0x70,0x90,0x90,0x90,0x70,
};

static BitmapCharRec ch113 = {4,6,-1,1,5,ch113data};

/* char: 0x70 'p' */

static GLubyte ch112data[] = {
0x80,0xe0,0x90,0x90,0x90,0xe0,
};

static BitmapCharRec ch112 = {4,6,-1,1,5,ch112data};

/* char: 0x6f 'o' */

static GLubyte ch111data[] = {
0x60,0x90,0x90,0x90,0x60,
};

static BitmapCharRec ch111 = {4,5,-1,0,5,ch111data};

/* char: 0x6e 'n' */

static GLubyte ch110data[] = {
0x90,0x90,0x90,0x90,0xe0,
};

static BitmapCharRec ch110 = {4,5,-1,0,5,ch110data};

/* char: 0x6d 'm' */

static GLubyte ch109data[] = {
0xa8,0xa8,0xa8,0xa8,0xf0,
};

static BitmapCharRec ch109 = {5,5,-1,0,6,ch109data};

/* char: 0x6c 'l' */

static GLubyte ch108data[] = {
0x80,0x80,0x80,0x80,0x80,0x80,0x80,
};

static BitmapCharRec ch108 = {1,7,-1,0,2,ch108data};

/* char: 0x6b 'k' */

static GLubyte ch107data[] = {
0xa0,0xa0,0xc0,0xc0,0xa0,0x80,0x80,
};

static BitmapCharRec ch107 = {3,7,-1,0,4,ch107data};

/* char: 0x6a 'j' */

static GLubyte ch106data[] = {
0x80,0x40,0x40,0x40,0x40,0x40,0x40,0x0,0x40,
};

static BitmapCharRec ch106 = {2,9,0,2,2,ch106data};

/* char: 0x69 'i' */

static GLubyte ch105data[] = {
0x80,0x80,0x80,0x80,0x80,0x0,0x80,
};

static BitmapCharRec ch105 = {1,7,-1,0,2,ch105data};

/* char: 0x68 'h' */

static GLubyte ch104data[] = {
0x90,0x90,0x90,0x90,0xe0,0x80,0x80,
};

static BitmapCharRec ch104 = {4,7,-1,0,5,ch104data};

/* char: 0x67 'g' */

static GLubyte ch103data[] = {
0x60,0x10,0x70,0x90,0x90,0x70,
};

static BitmapCharRec ch103 = {4,6,-1,1,5,ch103data};

/* char: 0x66 'f' */

static GLubyte ch102data[] = {
0x40,0x40,0x40,0x40,0xe0,0x40,0x20,
};

static BitmapCharRec ch102 = {3,7,-1,0,3,ch102data};

/* char: 0x65 'e' */

static GLubyte ch101data[] = {
0x60,0x80,0xe0,0xa0,0x40,
};

static BitmapCharRec ch101 = {3,5,-1,0,4,ch101data};

/* char: 0x64 'd' */

static GLubyte ch100data[] = {
0x70,0x90,0x90,0x90,0x70,0x10,0x10,
};

static BitmapCharRec ch100 = {4,7,-1,0,5,ch100data};

/* char: 0x63 'c' */

static GLubyte ch99data[] = {
0x60,0x80,0x80,0x80,0x60,
};

static BitmapCharRec ch99 = {3,5,-1,0,4,ch99data};

/* char: 0x62 'b' */

static GLubyte ch98data[] = {
0xe0,0x90,0x90,0x90,0xe0,0x80,0x80,
};

static BitmapCharRec ch98 = {4,7,-1,0,5,ch98data};

/* char: 0x61 'a' */

static GLubyte ch97data[] = {
0xd0,0xa0,0xe0,0x20,0xc0,
};

static BitmapCharRec ch97 = {4,5,-1,0,4,ch97data};

/* char: 0x60 '`' */

static GLubyte ch96data[] = {
0x80,0x80,0x80,
};

static BitmapCharRec ch96 = {1,3,-1,-3,2,ch96data};

/* char: 0x5f '_' */

static GLubyte ch95data[] = {
0xf8,
};

static BitmapCharRec ch95 = {5,1,0,1,5,ch95data};

/* char: 0x5e '^' */

static GLubyte ch94data[] = {
0x88,0x50,0x20,
};

static BitmapCharRec ch94 = {5,3,0,-2,5,ch94data};

/* char: 0x5d ']' */

static GLubyte ch93data[] = {
0xc0,0x40,0x40,0x40,0x40,0x40,0xc0,
};

static BitmapCharRec ch93 = {2,7,0,1,2,ch93data};

/* char: 0x5c '\' */

static GLubyte ch92data[] = {
0x40,0x40,0x40,0x40,0x80,0x80,0x80,
};

static BitmapCharRec ch92 = {2,7,0,1,2,ch92data};

/* char: 0x5b '[' */

static GLubyte ch91data[] = {
0xc0,0x80,0x80,0x80,0x80,0x80,0xc0,
};

static BitmapCharRec ch91 = {2,7,-1,1,2,ch91data};

/* char: 0x5a 'Z' */

static GLubyte ch90data[] = {
0xf0,0x80,0x40,0x20,0x10,0xf0,
};

static BitmapCharRec ch90 = {4,6,-2,0,6,ch90data};

/* char: 0x59 'Y' */

static GLubyte ch89data[] = {
0x20,0x20,0x30,0x48,0x48,0xc8,
};

static BitmapCharRec ch89 = {5,6,-1,0,6,ch89data};

/* char: 0x58 'X' */

static GLubyte ch88data[] = {
0x90,0x90,0x60,0x60,0x90,0x90,
};

static BitmapCharRec ch88 = {4,6,-2,0,6,ch88data};

/* char: 0x57 'W' */

static GLubyte ch87data[] = {
0x48,0x48,0x6c,0x92,0x92,0x92,
};

static BitmapCharRec ch87 = {7,6,-1,0,7,ch87data};

/* char: 0x56 'V' */

static GLubyte ch86data[] = {
0x40,0xa0,0x90,0x90,0x90,0x90,
};

static BitmapCharRec ch86 = {4,6,-2,0,6,ch86data};

/* char: 0x55 'U' */

static GLubyte ch85data[] = {
0x70,0x88,0x88,0x88,0x88,0x88,
};

static BitmapCharRec ch85 = {5,6,-1,0,6,ch85data};

/* char: 0x54 'T' */

static GLubyte ch84data[] = {
0x40,0x40,0x40,0x40,0x40,0xe0,
};

static BitmapCharRec ch84 = {3,6,-1,0,4,ch84data};

/* char: 0x53 'S' */

static GLubyte ch83data[] = {
0xe0,0x10,0x10,0xe0,0x80,0x70,
};

static BitmapCharRec ch83 = {4,6,-2,0,6,ch83data};

/* char: 0x52 'R' */

static GLubyte ch82data[] = {
0x90,0x90,0xe0,0x90,0x90,0xe0,
};

static BitmapCharRec ch82 = {4,6,-2,0,6,ch82data};

/* char: 0x51 'Q' */

static GLubyte ch81data[] = {
0x10,0x20,0x70,0x88,0x88,0x88,0x88,0x70,
};

static BitmapCharRec ch81 = {5,8,-1,2,6,ch81data};

/* char: 0x50 'P' */

static GLubyte ch80data[] = {
0x80,0x80,0xe0,0x90,0x90,0xe0,
};

static BitmapCharRec ch80 = {4,6,-2,0,6,ch80data};

/* char: 0x4f 'O' */

static GLubyte ch79data[] = {
0x70,0x88,0x88,0x88,0x88,0x70,
};

static BitmapCharRec ch79 = {5,6,-1,0,6,ch79data};

/* char: 0x4e 'N' */

static GLubyte ch78data[] = {
0x88,0x98,0xa8,0xa8,0xc8,0x88,
};

static BitmapCharRec ch78 = {5,6,-1,0,6,ch78data};

/* char: 0x4d 'M' */

static GLubyte ch77data[] = {
0xa8,0xa8,0xa8,0xa8,0xd8,0x88,
};

static BitmapCharRec ch77 = {5,6,-2,0,7,ch77data};

/* char: 0x4c 'L' */

static GLubyte ch76data[] = {
0xe0,0x80,0x80,0x80,0x80,0x80,
};

static BitmapCharRec ch76 = {3,6,-2,0,5,ch76data};

/* char: 0x4b 'K' */

static GLubyte ch75data[] = {
0x90,0x90,0xe0,0xc0,0xa0,0x90,
};

static BitmapCharRec ch75 = {4,6,-2,0,6,ch75data};

/* char: 0x4a 'J' */

static GLubyte ch74data[] = {
0x40,0xa0,0x20,0x20,0x20,0x20,
};

static BitmapCharRec ch74 = {3,6,-1,0,4,ch74data};

/* char: 0x49 'I' */

static GLubyte ch73data[] = {
0x80,0x80,0x80,0x80,0x80,0x80,
};

static BitmapCharRec ch73 = {1,6,-1,0,2,ch73data};

/* char: 0x48 'H' */

static GLubyte ch72data[] = {
0x88,0x88,0x88,0xf8,0x88,0x88,
};

static BitmapCharRec ch72 = {5,6,-1,0,6,ch72data};

/* char: 0x47 'G' */

static GLubyte ch71data[] = {
0x70,0x88,0x88,0x98,0x80,0x70,
};

static BitmapCharRec ch71 = {5,6,-1,0,6,ch71data};

/* char: 0x46 'F' */

static GLubyte ch70data[] = {
0x80,0x80,0x80,0xe0,0x80,0xf0,
};

static BitmapCharRec ch70 = {4,6,-2,0,5,ch70data};

/* char: 0x45 'E' */

static GLubyte ch69data[] = {
0xf0,0x80,0x80,0xe0,0x80,0xf0,
};

static BitmapCharRec ch69 = {4,6,-2,0,6,ch69data};

/* char: 0x44 'D' */

static GLubyte ch68data[] = {
0xf0,0x88,0x88,0x88,0x88,0xf0,
};

static BitmapCharRec ch68 = {5,6,-1,0,6,ch68data};

/* char: 0x43 'C' */

static GLubyte ch67data[] = {
0x70,0x88,0x80,0x80,0x88,0x70,
};

static BitmapCharRec ch67 = {5,6,-1,0,6,ch67data};

/* char: 0x42 'B' */

static GLubyte ch66data[] = {
0xe0,0x90,0x90,0xe0,0x90,0xe0,
};

static BitmapCharRec ch66 = {4,6,-2,0,6,ch66data};

/* char: 0x41 'A' */

static GLubyte ch65data[] = {
0x88,0x88,0x70,0x50,0x20,0x20,
};

static BitmapCharRec ch65 = {5,6,-1,0,6,ch65data};

/* char: 0x40 '@' */

static GLubyte ch64data[] = {
0x78,0x80,0x9e,0xa5,0x99,0x41,0x3e,
};

static BitmapCharRec ch64 = {8,7,-1,1,9,ch64data};

/* char: 0x3f '?' */

static GLubyte ch63data[] = {
0x40,0x0,0x40,0x20,0xc0,
};

static BitmapCharRec ch63 = {3,5,-2,0,5,ch63data};

/* char: 0x3e '>' */

static GLubyte ch62data[] = {
0x80,0x40,0x20,0x40,0x80,
};

static BitmapCharRec ch62 = {3,5,-2,0,5,ch62data};

/* char: 0x3d '=' */

static GLubyte ch61data[] = {
0xe0,0x0,0xe0,
};

static BitmapCharRec ch61 = {3,3,-1,-1,4,ch61data};

/* char: 0x3c '<' */

static GLubyte ch60data[] = {
0x20,0x40,0x80,0x40,0x20,
};

static BitmapCharRec ch60 = {3,5,-1,0,5,ch60data};

/* char: 0x3b ';' */

static GLubyte ch59data[] = {
0x80,0x40,0x40,0x0,0x0,0x40,
};

static BitmapCharRec ch59 = {2,6,0,2,2,ch59data};

/* char: 0x3a ':' */

static GLubyte ch58data[] = {
0x80,0x0,0x0,0x80,
};

static BitmapCharRec ch58 = {1,4,-1,0,2,ch58data};

/* char: 0x39 '9' */

static GLubyte ch57data[] = {
0x60,0x10,0x70,0x90,0x90,0x60,
};

static BitmapCharRec ch57 = {4,6,-1,0,5,ch57data};

/* char: 0x38 '8' */

static GLubyte ch56data[] = {
0x60,0x90,0x90,0x60,0x90,0x60,
};

static BitmapCharRec ch56 = {4,6,-1,0,5,ch56data};

/* char: 0x37 '7' */

static GLubyte ch55data[] = {
0x40,0x40,0x40,0x20,0x10,0xf0,
};

static BitmapCharRec ch55 = {4,6,-1,0,5,ch55data};

/* char: 0x36 '6' */

static GLubyte ch54data[] = {
0x60,0x90,0x90,0xe0,0x80,0x70,
};

static BitmapCharRec ch54 = {4,6,-1,0,5,ch54data};

/* char: 0x35 '5' */

static GLubyte ch53data[] = {
0xc0,0x20,0x20,0xc0,0x80,0xe0,
};

static BitmapCharRec ch53 = {3,6,-2,0,5,ch53data};

/* char: 0x34 '4' */

static GLubyte ch52data[] = {
0x20,0x20,0xf0,0x60,0x20,0x20,
};

static BitmapCharRec ch52 = {4,6,-1,0,5,ch52data};

/* char: 0x33 '3' */

static GLubyte ch51data[] = {
0xc0,0x20,0x20,0xc0,0x20,0xc0,
};

static BitmapCharRec ch51 = {3,6,-2,0,5,ch51data};

/* char: 0x32 '2' */

static GLubyte ch50data[] = {
0xf0,0x40,0x20,0x10,0x90,0x60,
};

static BitmapCharRec ch50 = {4,6,-1,0,5,ch50data};

/* char: 0x31 '1' */

static GLubyte ch49data[] = {
0x40,0x40,0x40,0x40,0xc0,0x40,
};

static BitmapCharRec ch49 = {2,6,-2,0,5,ch49data};

/* char: 0x30 '0' */

static GLubyte ch48data[] = {
0x60,0x90,0x90,0x90,0x90,0x60,
};

static BitmapCharRec ch48 = {4,6,-1,0,5,ch48data};

/* char: 0x2f '/' */

static GLubyte ch47data[] = {
0x80,0x80,0x80,0x80,0x40,0x40,0x40,
};

static BitmapCharRec ch47 = {2,7,-1,1,2,ch47data};

/* char: 0x2e '.' */

static GLubyte ch46data[] = {
0x80,
};

static BitmapCharRec ch46 = {1,1,-1,0,2,ch46data};

/* char: 0x2d '-' */

static GLubyte ch45data[] = {
0xf0,
};

static BitmapCharRec ch45 = {4,1,-2,-2,6,ch45data};

/* char: 0x2c ',' */

static GLubyte ch44data[] = {
0x80,0x40,0x40,
};

static BitmapCharRec ch44 = {2,3,0,2,2,ch44data};

/* char: 0x2b '+' */

static GLubyte ch43data[] = {
0x20,0x20,0xf8,0x20,0x20,
};

static BitmapCharRec ch43 = {5,5,-1,0,5,ch43data};

/* char: 0x2a '*' */

static GLubyte ch42data[] = {
0x40,0xe0,0x40,
};

static BitmapCharRec ch42 = {3,3,-1,-2,3,ch42data};

/* char: 0x29 ')' */

static GLubyte ch41data[] = {
0x80,0x40,0x40,0x40,0x40,0x40,0x80,
};

static BitmapCharRec ch41 = {2,7,-1,1,3,ch41data};

/* char: 0x28 '(' */

static GLubyte ch40data[] = {
0x40,0x80,0x80,0x80,0x80,0x80,0x40,
};

static BitmapCharRec ch40 = {2,7,-1,1,3,ch40data};

/* char: 0x27 ''' */

static GLubyte ch39data[] = {
0x80,0x80,0x80,
};

static BitmapCharRec ch39 = {1,3,-1,-3,2,ch39data};

/* char: 0x26 '&' */

static GLubyte ch38data[] = {
0x58,0xb0,0xa8,0x48,0xa0,0x40,
};

static BitmapCharRec ch38 = {5,6,-1,0,6,ch38data};

/* char: 0x25 '%' */

static GLubyte ch37data[] = {
0x5c,0x54,0x2c,0xd0,0xa8,0xe8,
};

static BitmapCharRec ch37 = {6,6,-1,0,7,ch37data};

/* char: 0x24 '$' */

static GLubyte ch36data[] = {
0x40,0xe0,0x10,0x60,0x80,0x70,0x20,
};

static BitmapCharRec ch36 = {4,7,-1,1,5,ch36data};

/* char: 0x23 '#' */

static GLubyte ch35data[] = {
0x50,0xf8,0x50,0xf8,0x50,
};

static BitmapCharRec ch35 = {5,5,0,0,5,ch35data};

/* char: 0x22 '"' */

static GLubyte ch34data[] = {
0xa0,0xa0,0xa0,
};

static BitmapCharRec ch34 = {3,3,-1,-3,3,ch34data};

/* char: 0x21 '!' */

static GLubyte ch33data[] = {
0x80,0x0,0x80,0x80,0x80,0x80,
};

static BitmapCharRec ch33 = {1,6,-1,0,2,ch33data};

/* char: 0x20 ' ' */

static GLubyte ch32data[] = {
0x0,
};

static BitmapCharRec ch32 = {1,1,0,0,2,ch32data};

/* char: 0x11 '\t' */

#ifdef WIN32
/* XXX Work around Microsoft OpenGL 1.1 bug where glBitmap with
   a height or width of zero does not advance the raster position
   as specified by OpenGL. (Cosmo OpenGL does not have this bug.) */
static const GLubyte ch9data[] = { 0x0 };
static const BitmapCharRec ch9 = {1,1,0,0,8,ch9data};
#else
static const BitmapCharRec ch9 = {0,0,0,0,8,0};
#endif

static const BitmapCharRec * const chars[] = {
&ch9,
0,
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0, 
0,
&ch32,
&ch33,
&ch34,
&ch35,
&ch36,
&ch37,
&ch38,
&ch39,
&ch40,
&ch41,
&ch42,
&ch43,
&ch44,
&ch45,
&ch46,
&ch47,
&ch48,
&ch49,
&ch50,
&ch51,
&ch52,
&ch53,
&ch54,
&ch55,
&ch56,
&ch57,
&ch58,
&ch59,
&ch60,
&ch61,
&ch62,
&ch63,
&ch64,
&ch65,
&ch66,
&ch67,
&ch68,
&ch69,
&ch70,
&ch71,
&ch72,
&ch73,
&ch74,
&ch75,
&ch76,
&ch77,
&ch78,
&ch79,
&ch80,
&ch81,
&ch82,
&ch83,
&ch84,
&ch85,
&ch86,
&ch87,
&ch88,
&ch89,
&ch90,
&ch91,
&ch92,
&ch93,
&ch94,
&ch95,
&ch96,
&ch97,
&ch98,
&ch99,
&ch100,
&ch101,
&ch102,
&ch103,
&ch104,
&ch105,
&ch106,
&ch107,
&ch108,
&ch109,
&ch110,
&ch111,
&ch112,
&ch113,
&ch114,
&ch115,
&ch116,
&ch117,
&ch118,
&ch119,
&ch120,
&ch121,
&ch122,
&ch123,
&ch124,
&ch125,
&ch126,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
&ch160,
&ch161,
&ch162,
&ch163,
&ch164,
&ch165,
&ch166,
&ch167,
&ch168,
&ch169,
&ch170,
&ch171,
&ch172,
&ch173,
&ch174,
&ch175,
&ch176,
&ch177,
&ch178,
&ch179,
&ch180,
&ch181,
&ch182,
&ch183,
&ch184,
&ch185,
&ch186,
&ch187,
&ch188,
&ch189,
&ch190,
&ch191,
&ch192,
&ch193,
&ch194,
&ch195,
&ch196,
&ch197,
&ch198,
&ch199,
&ch200,
&ch201,
&ch202,
&ch203,
&ch204,
&ch205,
&ch206,
&ch207,
&ch208,
&ch209,
&ch210,
&ch211,
&ch212,
&ch213,
&ch214,
&ch215,
&ch216,
&ch217,
&ch218,
&ch219,
&ch220,
&ch221,
&ch222,
&ch223,
&ch224,
&ch225,
&ch226,
&ch227,
&ch228,
&ch229,
&ch230,
&ch231,
&ch232,
&ch233,
&ch234,
&ch235,
&ch236,
&ch237,
&ch238,
&ch239,
&ch240,
&ch241,
&ch242,
&ch243,
&ch244,
&ch245,
&ch246,
&ch247,
&ch248,
&ch249,
&ch250,
&ch251,
&ch252,
&ch253,
&ch254,
&ch255,
};

BitmapFontRec glutBitmapHelveticaBold8 = {
"-adobe-helvetica-medium-r-normal--8-80-75-75-p-46-iso8859-1",
248,
9,
chars
};

