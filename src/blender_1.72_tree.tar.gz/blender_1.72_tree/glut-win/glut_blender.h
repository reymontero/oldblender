/********************************
 * glut_blender.h
 * written by Henry Neijhorst
 *
 * why o why
 *******************************/
