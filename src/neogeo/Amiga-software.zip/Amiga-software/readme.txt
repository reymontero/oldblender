This is code from NeoGeo BV, written by Ton Roosendaal and Frank van Beek.
Code is being provided "as is", use at own risk!

Amsterdam, 30 October 2017
Ton Roosendaal, ton@blender.org

Enjoy!


